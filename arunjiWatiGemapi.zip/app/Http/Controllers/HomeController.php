<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use DateTime;

class HomeController extends Controller
{
    
 public function index(Request $request)
{
    $payload = $request->getContent();
    Log::info('Webhook received', ['payload' => $payload]);
    //$this->thankyouMsg();
    $payload = json_decode($payload, true);
    $data = str_replace("#moonsign", "", $payload['text']);
    $dateTimeStr = trim($data);

    // Normalize the time part if the hour part is a single digit
    $dateTimeParts = explode(' ', $dateTimeStr);
    if (count($dateTimeParts) == 2) {
        list($dateStr, $timeStr) = $dateTimeParts;
        $timeParts = explode(':', $timeStr);
        if (count($timeParts) == 3 && strlen($timeParts[0]) == 1) {
            $timeParts[0] = str_pad($timeParts[0], 2, '0', STR_PAD_LEFT);
            $dateTimeStr = $dateStr . ' ' . implode(':', $timeParts);
        }
    }

    // Define the possible formats
    $formats = ['Y-m-d H:i:s', 'Y/m/d H:i:s'];

    $dateTime = false;
    foreach ($formats as $format) {
        $dateTime = DateTime::createFromFormat($format, $dateTimeStr);
        // Check if the date was created successfully and if it matches the format
        if ($dateTime && $dateTime->format($format) === $dateTimeStr) {
            break;
        }
    }

    if ($dateTime) {
        Log::info('msg send');
        return $this->sendMsg($dateTime->format('Y-m-d H:i:s'));
    } else {
        Log::info('msg fail', ['date' => $dateTime, 'other' => $dateTimeStr]);
        return false;
    }
}

    
    
      public function calculateMoonsign($dateTime)
    {
        Log::info('Calculating Moonsign for DateTime', ['dateTime' => $dateTime]);
        
        $apiUrl = "https://uat.bloomxapi.in/api/moonsign/calculateMoonsign";
       
        
        // Define the request body
        $requestBody = [
            "date" => $dateTime,
            "timezone" => "Asia/Kolkata",
        ];
    
        try {
           
            $responseData = Http::post($apiUrl, $requestBody);
            // // Extract details from the response
            // $this->rashi = $responseData['rashi'];
            // $this->rudraksh = $responseData['rudraksh'];
            // $this->gems = $responseData['gems'];
            // $this->bracelet = $responseData['bracelet'];

   
            return $responseData;
    
            if ($response->successful()) {
                // Get the JSON response body
                $responseData = $response->json();
    
                // Process the response data as needed
                // For example, return the response data
                return response()->json($responseData);
            } else {
                // Handle the case where the API request was not successful
                // For example, log the error and return an error response
                $statusCode = $response->status();
                $errorBody = $response->body();
                Log::error('API request failed', ['status' => $statusCode, 'body' => $errorBody]);
                return response()->json(['error' => 'API request failed', 'details' => $errorBody], $statusCode);
            }
        } catch (\Exception $e) {
            // Handle exceptions that occur during the API request
            // For example, log the exception and return an error response
            Log::error('Exception during API request', ['message' => $e->getMessage()]);
            return response()->json(['error' => 'Exception during API request', 'message' => $e->getMessage()], 500);
        }
        
    }

    public function getWaidFromLog(){
        
    }
    public function sendMsg($dateTime)
    {
        Log::info('Sending Message with DateTime', ['dateTime' => $dateTime]);
        //getting phone number from log file and seperate it 
        $logFilePath = storage_path('logs/laravel.log');
        $waId = null;

        if (File::exists($logFilePath)) {

            $logData = File::get($logFilePath);


            $logLines = explode("\n", $logData);

            foreach ($logLines as $line) {
                // Check if the line contains the "Webhook received" log entry
                if (strpos($line, 'Webhook received') !== false) {
                    // Extract the JSON payload
                    $start = strpos($line, '{"payload":');
                    if ($start !== false) {
                        $jsonString = substr($line, $start);
                        $data = json_decode($jsonString, true);

                        if (isset($data['payload'])) {
                            $payload = json_decode($data['payload'], true);
                            $waId = $payload['waId'];
                            break;

                        }
                    }
                }
            }
        }

        $responseData = $this->calculateMoonsign($dateTime);
        $data = json_decode($responseData,true);
        

        //call wati send message api and send msg to visitor
        $url = "https://live-mt-server.wati.io/102281/api/v1/sendTemplateMessage?whatsappNumber=".$waId;
        $headers = [
                        'Authorization' => 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI3MTFhODg1ZC1lYjg1LTRjYTMtOGU3MC01M2Y1MGQ0MWQzZWUiLCJ1bmlxdWVfbmFtZSI6InNob3BpZnlob2JAZ21haWwuY29tIiwibmFtZWlkIjoic2hvcGlmeWhvYkBnbWFpbC5jb20iLCJlbWFpbCI6InNob3BpZnlob2JAZ21haWwuY29tIiwiYXV0aF90aW1lIjoiMDUvMTgvMjAyNCAwNjoxODo1NiIsImRiX25hbWUiOiJtdC1wcm9kLVRlbmFudHMiLCJ0ZW5hbnRfaWQiOiIxMDIyODEiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJBRE1JTklTVFJBVE9SIiwiZXhwIjoyNTM0MDIzMDA4MDAsImlzcyI6IkNsYXJlX0FJIiwiYXVkIjoiQ2xhcmVfQUkifQ.huevMl63T9-w3UJV49I5SQ6ePT7RUIYIA57irRS122g',
                            'Accept' => 'application/json',
                            'Content-Type' => 'application/json',
        ];
        $body = [
            "template_name" => "gemapi",
            "broadcast_name" => "none",
            "parameters" => [
                        [
                            "name" => "rashi",
                            "value" => $data['rashi']['rashi'] ?? 'N/A'
                        ],
                        [
                            "name" => "rudraksh",
                            "value" => $data['rudraksh'][0]['name'] ?? 'N/A'
                        ],
                        [
                            "name" => "gems",
                            "value" => $data['gems'][0]['name'] ?? 'N/A'
                        ],
                        [
                            "name" => "bracelet",
                            "value" => $data['bracelet'][0]['name'] ?? 'N/A'
                        ]
            ]
        
            
        ];

        try {
            $response = Http::withHeaders($headers)->post($url, $body);

            if ($response->successful()) {
                return response()->json($response->json());
            } else {
                $responseBody = $response->body();
                return response()->json(['error' => 'API request failed', 'details' => $responseBody], $response->status());
            }
        } catch (\Exception $e) {
            return response()->json(['error' => 'Exception during API request', 'message' => $e->getMessage()], 500);
        }
    
    }
    
    public function thankyouMsg(){
        {
        Log::info('thankyou');
        //getting phone number from log file and seperate it 
        $logFilePath = storage_path('logs/laravel.log');
        $waId = null;

        if (File::exists($logFilePath)) {

            $logData = File::get($logFilePath);


            $logLines = explode("\n", $logData);

            foreach ($logLines as $line) {
                // Check if the line contains the "Webhook received" log entry
                if (strpos($line, 'Webhook received') !== false) {
                    // Extract the JSON payload
                    $start = strpos($line, '{"payload":');
                    if ($start !== false) {
                        $jsonString = substr($line, $start);
                        $data = json_decode($jsonString, true);

                        if (isset($data['payload'])) {
                            $payload = json_decode($data['payload'], true);
                            $waId = $payload['waId'];
                            break;

                        }
                    }
                }
            }
        }

        //call wati send message api and send msg to visitor
        $url = "https://live-mt-server.wati.io/102281/api/v1/sendTemplateMessage?whatsappNumber=".$waId;
        $headers = [
                        'Authorization' => 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI3MTFhODg1ZC1lYjg1LTRjYTMtOGU3MC01M2Y1MGQ0MWQzZWUiLCJ1bmlxdWVfbmFtZSI6InNob3BpZnlob2JAZ21haWwuY29tIiwibmFtZWlkIjoic2hvcGlmeWhvYkBnbWFpbC5jb20iLCJlbWFpbCI6InNob3BpZnlob2JAZ21haWwuY29tIiwiYXV0aF90aW1lIjoiMDUvMTgvMjAyNCAwNjoxODo1NiIsImRiX25hbWUiOiJtdC1wcm9kLVRlbmFudHMiLCJ0ZW5hbnRfaWQiOiIxMDIyODEiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJBRE1JTklTVFJBVE9SIiwiZXhwIjoyNTM0MDIzMDA4MDAsImlzcyI6IkNsYXJlX0FJIiwiYXVkIjoiQ2xhcmVfQUkifQ.huevMl63T9-w3UJV49I5SQ6ePT7RUIYIA57irRS122g',
                            'Accept' => 'application/json',
                            'Content-Type' => 'application/json',
        ];
        $body = [
            "template_name" => "thankyou_gempi",
            "broadcast_name" => "none",
            "parameters" => [
                        
            ]
        
            
        ];

        try {
            $response = Http::withHeaders($headers)->post($url, $body);

            if ($response->successful()) {
                return response()->json($response->json());
            } else {
                $responseBody = $response->body();
                return response()->json(['error' => 'API request failed', 'details' => $responseBody], $response->status());
            }
        } catch (\Exception $e) {
            return response()->json(['error' => 'Exception during API request', 'message' => $e->getMessage()], 500);
        }
    
    }
    }
   
}
