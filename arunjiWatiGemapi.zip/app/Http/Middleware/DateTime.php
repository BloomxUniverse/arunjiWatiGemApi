<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Log;

class DateTimeMiddleware
{
    public function handle($request, Closure $next)
    {
        $payload = $request->getContent();
        $pattern = '/#moonsign (\d{2}-\d{2}-\d{4} \d{2}:\d{2})/';

        if (preg_match($pattern, $payload, $matches)) {
            $dateTimeStr = $matches[1];

            list($dateStr, $timeStr) = explode(' ', $dateTimeStr);

            $dateObj = \DateTime::createFromFormat('d-m-Y', $dateStr);
            $formattedDateStr = $dateObj->format('Y-m-d');
            $dateTime = $formattedDateStr . ' ' . $timeStr;

            // Store the calculated moon sign in the session
            session()->put('fulldate', $dateTime);

            Log::info('Extracted Date and Time', ['date' => $dateTime]);
        } else {
            Log::warning('Invalid message format', ['payload' => $payload]);
        }

        return $next($request);
    }
}
